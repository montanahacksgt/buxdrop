import './Maintenance.css'

export default function Maintenance () {
    return (
        <p>We are upgrading our site! https://discord.gg/FdMBKTwzHy</p>
    )
}